var data=
{
  "server"	:	"https://github.com/",
  "path"	: 	"vlecompte/FLTest/BldTest008_external_git/mixed/external.zip"
}